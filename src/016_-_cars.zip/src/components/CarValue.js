function CarValue() {
  return <div>CarValue</div>;
}

export default CarValue;
